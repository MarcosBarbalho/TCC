<?php 
//echo "Olá, mundo!";
$titulo = "TCC";
 ?>
<title><?php echo $titulo; ?></title>
<h1>TMNC TAPITA</h1>
<p>Index:</p>
<p><a href="html/login.html">Login</a></p>
<p><a href="html/dashboard.html">Dashboard</a></p>

<style>
	h1 {
		color: blue;
		text-align: center;
	}
</style>